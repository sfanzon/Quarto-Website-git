# Data dictionary

## `qatar2023_odds.csv`

Pre-race outright win odds for the 2023 Qatar Grand Prix, reported in Table 1
of the paper (source cited there as bet365).

| column | meaning |
|---|---|
| `team` | 2023 constructor |
| `driver` | driver name (spelling normalised) |
| `odds` | fractional odds |
| `paper_probability` | renormalised probability printed in Table 1 |
| `paper_lambda` | rate printed in Table 1 (arbitrary common scale) |

The code independently recomputes the probabilities from `odds` and uses the
published columns only as regression-test references. Small differences at
about `1e-9` are caused by table rounding.

## `f1_2022_positions.txt`

Tab-separated file with no header:

- 20 rows, one per driver;
- first column: driver identifier;
- remaining 25 columns: 22 Grands Prix plus 3 sprint races from 2022;
- rows occur in teammate pairs, ordered by constructor;
- values are final classified positions from 1 to 20.

The file is byte-for-byte identical to the historical-results file in both
predecessor repositories.
