# Figure provenance

Every figure in `figures/` is produced by base R code stored in this repository.
There is no Python plotting step and no manual editing step in the canonical
workflow.

| File | Data/model object | Canonical plotting source |
|---|---|---|
| `01_lambda_estimates.png` | Qatar 2023 calibration table | `R/figures/_01_lambda_estimates.R` |
| `02_team_effects.png` | selected 2022 regression | `R/figures/_02_team_effects.R` |
| `03_driver_vs_team.png` | raw 2022 driver averages | `R/figures/_03_driver_vs_team.R` |
| `04_teammate_gaps.png` | 2023 odds-implied teammate gaps + 2022 threshold | `R/figures/_04_teammate_gaps.R` |

Regenerate them with:

```bash
Rscript analysis/generate_figures.R
```

or regenerate the figures together with all tables and CSV outputs:

```bash
Rscript analysis/reproduce_paper.R
```

The Quarto pages include the same plotting files verbatim using Quarto's
`include` shortcode. The project-level pre-render hook runs
`analysis/generate_figures.R`, so a normal `quarto render` regenerates the PNGs
from exactly the code displayed on the pages.

The committed starting PNGs were taken from the R-generated outputs in the two
uploaded predecessor repositories. They are present so the pages remain
viewable before the first local render; the current plotting functions become
canonical as soon as the pre-render step runs.
