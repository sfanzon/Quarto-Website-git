# ==============================================================================
# Generate all four figures without writing the paper tables.
#
# Run from anywhere with:
#   Rscript analysis/generate_figures.R
#
# Every figure is produced with base R. The plotting functions are separated
# under R/figures/ so the exact source can also be displayed in Quarto.
# ==============================================================================

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) != 1L) stop("run this file with Rscript")
script_path <- normalizePath(sub("^--file=", "", file_arg))
repo_root <- normalizePath(file.path(dirname(script_path), ".."))
setwd(repo_root)

source("R/00_palette.R")
source("R/00_utils.R")
source("R/01_odds_calibration.R")
source("R/02_rank_duality.R")
source("R/03_regression.R")
source("R/04_driver_effects.R")
source("R/05_visualization.R")

dir.create("figures", showWarnings = FALSE)

odds <- read_qatar_odds()
calibration <- build_calibration_table(odds)
dual <- implied_rank_params(odds$implied_probability)

f1 <- load_f1_2022()
models <- select_models(f1)
driver_averages <- driver_average_table(f1)

ci <- second_driver_ci(models$stepwise)
gaps <- teammate_gaps(odds, dual$mu, threshold = ci["upper"])

plot_lambda_estimates(calibration)
plot_team_effects(models$stepwise)
plot_driver_vs_team(driver_averages)
plot_teammate_gaps(gaps, threshold = ci["upper"])

cat("Generated:\n")
cat("  figures/01_lambda_estimates.png\n")
cat("  figures/02_team_effects.png\n")
cat("  figures/03_driver_vs_team.png\n")
cat("  figures/04_teammate_gaps.png\n")
