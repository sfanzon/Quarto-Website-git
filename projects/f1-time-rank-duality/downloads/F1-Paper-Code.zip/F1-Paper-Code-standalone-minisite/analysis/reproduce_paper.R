# ==============================================================================
# One-command reproduction of Tables 1-3 and Section 5.
# Run from anywhere with:
#   Rscript analysis/reproduce_paper.R
# ==============================================================================

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) != 1L) stop("run this file with Rscript")
script_path <- normalizePath(sub("^--file=", "", file_arg))
repo_root <- normalizePath(file.path(dirname(script_path), ".."))
setwd(repo_root)

source("R/00_palette.R")
source("R/00_utils.R")
source("R/01_odds_calibration.R")
source("R/02_rank_duality.R")
source("R/03_regression.R")
source("R/04_driver_effects.R")
source("R/05_visualization.R")

dir.create("figures", showWarnings = FALSE)
dir.create("output", showWarnings = FALSE)

# -------------------------------------------------------------------- Table 1
odds <- read_qatar_odds()
calibration <- build_calibration_table(odds)
numerical <- estimate_lambda_numerically(odds$implied_probability,
                                          restarts = 20, seed = 1)

cat("\nTABLE 1: Qatar 2023 odds and exponential rates\n")
print_table(calibration[, c("team", "driver", "odds", "implied_probability",
                            "lambda_paper_scale")], digits = 10)
cat(sprintf("\nPaper common scale (least-squares from rounded Table 1): %.12f\n",
            attr(calibration, "paper_scale")))
cat(sprintf("Maximum probability rounding error: %.3e\n",
            max(abs(calibration$probability_rounding_error))))
cat(sprintf("Maximum lambda rounding error: %.3e\n",
            max(abs(calibration$lambda_rounding_error))))
cat(sprintf("Numerical-vs-analytic normalised lambda difference: %.3e\n",
            max(abs(numerical$lambda - calibration$lambda_unit_sum))))

write.csv(calibration, "output/table1_calibration.csv", row.names = FALSE)

# -------------------------------------------------------------------- Table 2
dual <- implied_rank_params(odds$implied_probability)
table2 <- data.frame(
  team = odds$team,
  driver = odds$driver,
  odds = odds$odds,
  implied_probability = odds$implied_probability,
  mu_hat = dual$mu,
  stringsAsFactors = FALSE
)
cat(sprintf("\nTABLE 2: odds-implied Gaussian rank parameters (sigma_hat = %.6f)\n",
            dual$sigma))
print_table(table2, digits = 9)
write.csv(table2, "output/table2_rank_parameters.csv", row.names = FALSE)

# -------------------------------------------------------------------- Table 3
f1 <- load_f1_2022()
models <- select_models(f1)
table3 <- regression_table(models$stepwise)
cat("\nTABLE 3: constrained stepwise regression on 2022 results\n")
print_table(table3, digits = 6)
cat(sprintf("\nR-squared = %.4f; adjusted R-squared = %.4f\n",
            summary(models$stepwise)$r.squared,
            summary(models$stepwise)$adj.r.squared))
cat("\nStepwise-vs-backward model F-test:\n")
print(models$comparison)
write.csv(table3, "output/table3_regression.csv", row.names = FALSE)

# Descriptive driver averages used only in Figure 3.
driver_averages <- driver_average_table(f1)
write.csv(driver_averages, "output/driver_average_positions.csv", row.names = FALSE)

# ------------------------------------------------------------------ Section 5
ci <- second_driver_ci(models$stepwise)
gaps <- teammate_gaps(odds, dual$mu, threshold = ci["upper"])
cat(sprintf("\nSECTION 5: second-driver 95%% CI = (%.3f, %.3f)\n",
            ci["lower"], ci["upper"]))
print_table(gaps[, c("team", "leading_driver", "teammate", "leading_mu",
                     "teammate_mu", "gap", "outperforms_car")], digits = 6)
flagged <- gaps$leading_driver[gaps$outperforms_car]
cat("\nDrivers exceeding the paper's threshold: ",
    paste(flagged, collapse = ", "), "\n", sep = "")
write.csv(gaps, "output/section5_teammate_gaps.csv", row.names = FALSE)

# --------------------------------------------------------------------- Figures
plot_lambda_estimates(calibration)
plot_team_effects(models$stepwise)
plot_driver_vs_team(driver_averages)
plot_teammate_gaps(gaps, ci["upper"])
cat("\nWrote tables to output/ and four R-generated figures to figures/.\n")
