# ==============================================================================
# 05_visualization.R -- Base-R figures used by the Quarto explainers
#
# Each plotting function lives in its own file under R/figures/. This makes the
# exact code for every figure easy to display in the Quarto pages without
# duplicating it. All figures are generated using base R only.
# ==============================================================================

source("R/figures/_01_lambda_estimates.R")
source("R/figures/_02_team_effects.R")
source("R/figures/_03_driver_vs_team.R")
source("R/figures/_04_teammate_gaps.R")
