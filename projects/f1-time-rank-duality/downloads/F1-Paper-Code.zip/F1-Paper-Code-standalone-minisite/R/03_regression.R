# ==============================================================================
# 03_regression.R -- Historical rank regression (paper Section 4 / Table 3)
#
# The response is final classified position over 25 events in 2022. Candidate
# models include a compulsory second-driver indicator and constructor dummies;
# Williams is the omitted baseline. Model selection uses base-R step() (AIC),
# exactly as in the original companion analysis.
# ==============================================================================

load_f1_2022 <- function(path = "data/f1_2022_positions.txt") {
  raw <- read.table(path, sep = "\t", header = FALSE, quote = "",
                    stringsAsFactors = FALSE, check.names = FALSE)
  if (nrow(raw) != 20L || ncol(raw) != 26L) {
    stop("2022 data must be 20 drivers x (name + 25 events)")
  }

  drivers <- raw[[1]]
  positions <- as.matrix(raw[, -1, drop = FALSE])
  storage.mode(positions) <- "numeric"
  if (any(!is.finite(positions)) || any(positions < 1) || any(positions > 20)) {
    stop("finishing positions must be numeric values from 1 to 20")
  }

  team_order <- c("Mercedes", "RedBull", "Ferrari", "McLaren", "Alpine",
                  "AstonMartin", "Haas", "AlphaTauri", "AlfaRomeo", "Williams")
  constructors <- rep(team_order, each = 2)
  second_driver <- rep(c(0, 1), times = 10)
  n_events <- ncol(positions)

  data.frame(
    driver = rep(drivers, times = n_events),
    constructor = factor(rep(constructors, times = n_events), levels = team_order),
    second_driver = rep(second_driver, times = n_events),
    event = rep(seq_len(n_events), each = length(drivers)),
    position = as.vector(positions),
    stringsAsFactors = FALSE
  )
}

select_models <- function(df) {
  required <- c("constructor", "second_driver", "position")
  if (!all(required %in% names(df))) stop("regression data is missing required columns")

  team_terms <- c("Mercedes", "RedBull", "Ferrari", "McLaren", "Alpine",
                  "AstonMartin", "Haas", "AlphaTauri", "AlfaRomeo")
  df2 <- df
  for (tm in team_terms) df2[[tm]] <- as.integer(df2$constructor == tm)

  full_formula <- reformulate(c("second_driver", team_terms), response = "position")
  lower_formula <- position ~ second_driver
  full_model <- lm(full_formula, data = df2)
  lower_model <- lm(lower_formula, data = df2)
  scope <- list(lower = formula(lower_model), upper = formula(full_model))

  stepwise_model <- step(lower_model, scope = scope, direction = "both", trace = FALSE)
  forward_model <- step(lower_model, scope = scope, direction = "forward", trace = FALSE)
  backward_model <- step(full_model, scope = scope, direction = "backward", trace = FALSE)
  comparison <- anova(stepwise_model, backward_model, test = "F")

  list(stepwise = stepwise_model, forward = forward_model,
       backward = backward_model, comparison = comparison, data = df2)
}

regression_table <- function(model) {
  s <- summary(model)
  tab <- as.data.frame(s$coefficients)
  tab$term <- rownames(tab)
  rownames(tab) <- NULL
  tab <- tab[, c("term", "Estimate", "Std. Error", "t value", "Pr(>|t|)")]
  names(tab) <- c("term", "estimate", "std_error", "t_value", "p_value")
  tab
}

#' Driver-level descriptive averages from the 2022 results
#'
#' Returns one row per driver, retaining constructor and first/second-driver
#' status. These averages are used only for the descriptive Figure 3; the
#' Section 5 threshold is applied to 2023 odds-implied expected ranks instead.
#'
#' @param df long-form data returned by load_f1_2022()
#' @return data frame with driver, constructor, second_driver and avg_position
#' @export
driver_average_table <- function(df) {
  required <- c("driver", "constructor", "second_driver", "position")
  if (!all(required %in% names(df))) {
    stop("driver-average data is missing required columns")
  }

  metadata <- unique(df[, c("driver", "constructor", "second_driver")])
  averages <- aggregate(position ~ driver, data = df, FUN = mean)
  names(averages)[names(averages) == "position"] <- "avg_position"

  out <- merge(metadata, averages, by = "driver", sort = FALSE)
  team_levels <- levels(df$constructor)
  out$constructor <- factor(out$constructor, levels = team_levels)
  out <- out[order(out$constructor, out$second_driver), , drop = FALSE]
  rownames(out) <- NULL
  out
}
