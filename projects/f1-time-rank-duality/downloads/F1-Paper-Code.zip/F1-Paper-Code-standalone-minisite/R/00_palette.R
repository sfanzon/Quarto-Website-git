# ==============================================================================
# 00_palette.R -- warm analytical plotting palette
#
# These colours mirror the named palette used by silviofanzon.com. Keeping the
# names here makes every figure reproducible without depending on the website
# repository or on an external R package.
# ==============================================================================

SF_COLORS <- c(
  ink = "#241F1B",
  charcoal = "#1C1C1D",
  paper = "#FFFDF9",
  cream = "#F8F3EB",
  sand = "#E7DACB",
  stone = "#6A615A",
  rust = "#A8522F",
  rust_light = "#F4DED3",
  blue = "#3F6F8F",
  blue_light = "#E6EFF3",
  green = "#4F7A5A",
  green_light = "#E8F0E8",
  red = "#B84A47",
  red_light = "#F8E6E3",
  gold = "#B98528",
  gold_light = "#F8EED8",
  teal = "#3F7F79",
  plum = "#76506F",
  slate = "#647276",
  slate_light = "#C0C8C9"
)

sf_color <- function(name) {
  if (!name %in% names(SF_COLORS)) {
    stop(sprintf("unknown palette colour: %s", name))
  }
  unname(SF_COLORS[[name]])
}

sf_plot_par <- function(mar) {
  par(
    mar = mar,
    bg = sf_color("paper"),
    fg = sf_color("ink"),
    col.axis = sf_color("stone"),
    col.lab = sf_color("ink"),
    col.main = sf_color("ink"),
    family = "sans",
    bty = "l"
  )
}
