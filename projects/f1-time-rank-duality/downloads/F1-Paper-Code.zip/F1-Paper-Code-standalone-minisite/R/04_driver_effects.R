# ==============================================================================
# 04_driver_effects.R -- Driver-level comparison (paper Section 5)
#
# Correct paper logic:
#   1. Fit the 2022 historical regression and take the UPPER endpoint of the
#      second-driver 95% CI (about 1.013) as the threshold.
#   2. Translate 2023 Qatar bookmaker probabilities into Table 2 expected ranks
#      mu_i using time-rank duality.
#   3. Compare the two Table 2 mu_i values within each 2023 constructor.
#
# It is NOT correct to apply the threshold to raw 2022 season-average teammate
# positions. That was the key error in the previous dual-page repository.
# ==============================================================================

second_driver_ci <- function(model, level = 0.95) {
  if (!("second_driver" %in% names(coef(model)))) {
    stop("model does not contain second_driver")
  }
  ci <- confint(model, "second_driver", level = level)
  c(lower = unname(ci[1]), upper = unname(ci[2]))
}

teammate_gaps <- function(odds_df, mu, threshold) {
  if (length(mu) != nrow(odds_df)) stop("mu must match the rows of odds_df")
  if (!is.finite(threshold) || threshold <= 0) stop("threshold must be positive")

  odds_df$mu_hat <- mu
  teams <- unique(odds_df$team)
  rows <- lapply(teams, function(tm) {
    pair <- odds_df[odds_df$team == tm, , drop = FALSE]
    if (nrow(pair) != 2L) stop("each team must contain exactly two drivers")
    lead_index <- which.min(pair$mu_hat)
    mate_index <- setdiff(1:2, lead_index)
    gap <- pair$mu_hat[mate_index] - pair$mu_hat[lead_index]
    data.frame(
      team = tm,
      leading_driver = pair$driver[lead_index],
      teammate = pair$driver[mate_index],
      leading_mu = pair$mu_hat[lead_index],
      teammate_mu = pair$mu_hat[mate_index],
      gap = gap,
      threshold = threshold,
      outperforms_car = gap > threshold,
      stringsAsFactors = FALSE
    )
  })
  out <- do.call(rbind, rows)
  out[order(-out$gap), , drop = FALSE]
}
