# ==============================================================================
# 01_odds_calibration.R -- Exponential finishing-time model (paper Section 2)
#
# If T_i ~ Exp(lambda_i) independently, then
#   Pr(car i wins) = lambda_i / sum_j lambda_j.
#
# IMPORTANT: the likelihood/RSS identifies only the RATIOS of lambda. For any
# c > 0, lambda = c * p gives exactly the same win probabilities. The paper's
# Table 1 therefore reports one arbitrary positive scale, not uniquely
# identified absolute rates. This file makes that fact explicit.
# ==============================================================================

lambda_rss <- function(lambda, probs) {
  assert_probabilities(probs)
  if (!is.numeric(lambda) || length(lambda) != length(probs) ||
      any(!is.finite(lambda)) || any(lambda <= 0)) {
    stop("lambda must be a positive finite vector with the same length as probs")
  }
  fitted <- lambda / sum(lambda)
  sum((fitted - probs)^2)
}

# Exact analytic minimiser. scale = 1 gives sum(lambda) = 1 and lambda = probs.
lambda_from_probs <- function(probs, scale = 1) {
  assert_probabilities(probs)
  if (!is.numeric(scale) || length(scale) != 1L || !is.finite(scale) || scale <= 0) {
    stop("scale must be one positive finite number")
  }
  scale * probs
}

# Numerically reproduce the paper's minimisation after removing the scale
# degeneracy. One log-rate is fixed to zero; all rates are positive and the
# expanded vector is normalised to sum to one inside the objective.
estimate_lambda_numerically <- function(probs, restarts = 20L, seed = 1L) {
  assert_probabilities(probs)
  if (restarts < 1L) stop("restarts must be at least one")

  unique_probs <- sort(unique(probs))
  group_id <- match(probs, unique_probs)
  k <- length(unique_probs)

  objective <- function(eta_free) {
    eta <- c(eta_free, 0)
    group_rates <- exp(eta - max(eta))
    lambda <- group_rates[group_id]
    lambda <- lambda / sum(lambda)
    sum((lambda - probs)^2)
  }

  set.seed(seed)
  # Include the analytically implied log-ratio as a deterministic start, then
  # add random starts to verify that the constrained numerical formulation
  # returns the same normalised rates.
  starts <- list(log(unique_probs[-k] / unique_probs[k]))
  if (restarts > 1L) {
    starts <- c(starts, replicate(restarts - 1L, rnorm(k - 1L, sd = 1),
                                  simplify = FALSE))
  }

  best <- NULL
  for (start in starts) {
    fit <- optim(start, objective, method = "BFGS",
                 control = list(maxit = 10000, reltol = 1e-14))
    if (is.null(best) || fit$value < best$value) best <- fit
  }

  eta <- c(best$par, 0)
  group_rates <- exp(eta - max(eta))
  lambda <- group_rates[group_id]
  lambda <- lambda / sum(lambda)

  list(lambda = lambda, fitted_probability = lambda,
       rss = lambda_rss(lambda, probs), convergence = best$convergence)
}

# Published Table 1 values are rounded and use an arbitrary common scale.
# The least-squares scale below is the best common multiplier taking the
# published probabilities to the published lambda column.
paper_lambda_scale <- function(paper_probability, paper_lambda) {
  sum(paper_probability * paper_lambda) / sum(paper_probability^2)
}

build_calibration_table <- function(odds_df) {
  probs <- odds_df$implied_probability
  assert_probabilities(probs)
  scale <- paper_lambda_scale(odds_df$paper_probability, odds_df$paper_lambda)

  out <- odds_df
  out$lambda_unit_sum <- lambda_from_probs(probs, scale = 1)
  out$lambda_paper_scale <- lambda_from_probs(probs, scale = scale)
  out$probability_rounding_error <- out$implied_probability - out$paper_probability
  out$lambda_rounding_error <- out$lambda_paper_scale - out$paper_lambda
  attr(out, "paper_scale") <- scale
  out
}
