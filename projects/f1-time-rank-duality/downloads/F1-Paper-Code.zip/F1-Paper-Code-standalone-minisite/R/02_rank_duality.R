# ==============================================================================
# 02_rank_duality.R -- Time-rank duality (paper Section 3 / Table 2)
#
# Rank model: r_i ~ N(mu_i, sigma^2), with
#   p_i = Phi((1.5 - mu_i)/sigma).
# Under common sigma and sum_i mu_i = n(n+1)/2:
#   sigma = (n - n^2/2) / sum_i Phi^{-1}(p_i),
#   mu_i  = 1.5 - sigma Phi^{-1}(p_i).
# ==============================================================================

implied_rank_params <- function(probs) {
  assert_probabilities(probs)
  n <- length(probs)
  z <- qnorm(probs)
  denominator <- sum(z)
  if (!is.finite(denominator) || abs(denominator) < .Machine$double.eps) {
    stop("rank-duality scale is undefined for this probability vector")
  }
  sigma <- (n - n^2 / 2) / denominator
  if (!is.finite(sigma) || sigma <= 0) stop("computed sigma is not positive")
  mu <- 1.5 - sigma * z
  list(mu = mu, sigma = sigma, z = z)
}
