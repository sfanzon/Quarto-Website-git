# ==============================================================================
# 00_utils.R -- Shared validation, data-loading and printing helpers
#
# Companion code for:
# Fry, Brighton & Fanzon (2024), Economics Letters 237:111671.
# Base R only; no external packages are required.
# ==============================================================================

assert_probabilities <- function(probs, tol = 1e-8) {
  if (!is.numeric(probs) || length(probs) < 2L || any(!is.finite(probs))) {
    stop("probs must be a finite numeric vector of length at least two")
  }
  if (any(probs <= 0) || any(probs >= 1)) {
    stop("all probabilities must lie strictly between 0 and 1")
  }
  if (abs(sum(probs) - 1) > tol) {
    stop(sprintf("probabilities must sum to 1 (sum = %.12f)", sum(probs)))
  }
  invisible(TRUE)
}

parse_fractional_odds <- function(odds) {
  if (!is.character(odds) || any(!grepl("^[0-9.]+/[0-9.]+$", odds))) {
    stop("odds must be strings such as '25/1' or '2/9'")
  }
  vapply(strsplit(odds, "/", fixed = TRUE), function(ab) {
    numerator <- as.numeric(ab[1])
    denominator <- as.numeric(ab[2])
    if (!is.finite(numerator) || !is.finite(denominator) || denominator <= 0) {
      stop("invalid fractional odds")
    }
    numerator / denominator
  }, numeric(1))
}

# Convert fractional odds to proportional (de-vigged) implied probabilities.
odds_to_probs <- function(odds) {
  fractional <- parse_fractional_odds(odds)
  raw <- 1 / (fractional + 1)
  raw / sum(raw)
}

read_qatar_odds <- function(path = "data/qatar2023_odds.csv") {
  x <- read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("team", "driver", "odds", "paper_probability", "paper_lambda")
  if (!all(required %in% names(x))) {
    stop("Qatar odds data is missing required columns")
  }
  if (nrow(x) != 20L) stop("Qatar odds data must contain 20 drivers")
  team_sizes <- table(x$team)
  if (any(team_sizes != 2L)) stop("each constructor must have exactly two drivers")
  x$implied_probability <- odds_to_probs(x$odds)
  x
}

print_table <- function(df, digits = 7, title = NULL) {
  if (!is.null(title)) {
    cat("\n", title, "\n", strrep("-", nchar(title)), "\n", sep = "")
  }
  print(format(df, digits = digits, scientific = FALSE), row.names = FALSE)
  invisible(df)
}
