#' Figure 1: odds-implied exponential rates
#'
#' @param calibration output from build_calibration_table()
#' @param file output PNG path
plot_lambda_estimates <- function(
    calibration,
    file = "figures/01_lambda_estimates.png"
) {
  ord <- order(-calibration$lambda_paper_scale)
  driver_labels <- sub("^.* ", "", calibration$driver)

  png(file, width = 900, height = 650, res = 130, bg = sf_color("paper"))
  op <- sf_plot_par(c(7, 5, 3, 1))
  on.exit({
    par(op)
    dev.off()
  }, add = TRUE)

  barplot(
    calibration$lambda_paper_scale[ord],
    names.arg = driver_labels[ord],
    las = 2,
    col = sf_color("blue"),
    border = NA,
    ylab = expression(hat(lambda)),
    main = paste(
      "Estimated race-time rate per driver",
      "(2023 Qatar GP bookmakers' odds, exponential model)",
      sep = "\n"
    )
  )
  abline(h = 0, col = sf_color("sand"))

  invisible(file)
}
