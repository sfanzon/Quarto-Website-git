# Standalone mini-site

This repository owns its own Quarto build and deployment. It is not rendered as part of the main `silviofanzon.com` repository.

The mini-site deliberately uses a simple native Quarto structure:

- the shared-looking top navbar;
- local search and colour-mode controls;
- the technical walkthrough as the main page;
- Quarto's right-hand on-page table of contents;
- no left resource sidebar.

The main website contains only the polished project overview and links here for the technical material and source code.
