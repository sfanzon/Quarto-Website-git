# Repository audit and correction log

This audit compares:

1. the published paper and original companion page;
2. the earlier dual-page `F1-Paper-Code` repository;
3. the modular `F1 Blog and Code` repository.

## Conclusion

`F1 Blog and Code` had the better computational implementation. The dual-page
repository had the better presentation, but its Section 5 calculation was not
the one performed in the paper.

The corrected repository keeps the dual presentation and replaces the
computational core with a reviewed, validated implementation.

## Original companion-page issues

The original web listing was useful as a record of the published analysis, but
it was not a portable repository: it used the machine-specific path
`read.table("F:f1seconddata.txt")`, displayed an assignment as
`driverorder< - rep(...)`, and hard-coded the bookmaker probabilities inside
the calibration function. These are implementation problems, not changes to
the paper's mathematical argument.

## Main findings

| Component | Earlier dual-page repo | F1 Blog and Code | Corrected version |
|---|---|---|---|
| Qatar odds dataset | probabilities hard-coded in R | separate CSV | CSV with odds and published reference columns |
| 2022 results dataset | included | included | included unchanged |
| Table 1 | numerical optimisation + arbitrary rescaling | modular optimiser, scale differs | analytic solution + constrained optimiser check + published-scale comparison |
| Table 2 | missing from the R pipeline | implemented | implemented and tested |
| Table 3 | reproduced, but manually assembled | modular and tidy | modular, selected model used directly, tested |
| Section 5 | incorrectly used raw 2022 teammate averages | correctly used Table 2 odds-implied expected ranks | correct paper logic, tested |
| Documentation | strong dual Quarto pages | strong README/comments | dual Quarto pages + full reproducibility |

## The serious Section 5 issue

The paper does **not** apply the 1.013 threshold to raw average finishing
positions from the 2022 season. Its sequence is:

1. Table 3, fitted to 2022 results, supplies the second-driver confidence
   interval `(-0.581, 1.013)`.
2. Table 2 translates 2023 Qatar bookmaker probabilities into expected ranks
   `mu_i`.
3. Section 5 compares the two Table 2 `mu_i` values within each 2023 team.

That comparison gives gaps of approximately:

- Max Verstappen vs Sergio Perez: `7.669`;
- Fernando Alonso vs Lance Stroll: `2.403`.

Both exceed `1.013`. The earlier dual-page repo instead compared raw 2022
season averages, which produced a different question and an apparent Alonso
inconsistency. The raw-average calculation is retained only as a clearly labelled descriptive
figure. It is not used to identify the final pair of drivers; the corrected
Section 5 code uses the 2023 odds-implied expected ranks.

## Table 1 improvement

Both predecessor repositories treated the rates as an optimisation problem.
The paper's RSS is scale-invariant, so the absolute `lambda` values are not
identified. Mathematically, `lambda = c p` is an exact solution for any
positive `c`. The corrected implementation states this explicitly and avoids
presenting an arbitrary optimiser scale as uniquely estimated.

## Independent validation performed during this audit

The supplied datasets were independently checked against the paper's published
values. The following were reproduced:

- `sigma_hat = 3.879374`;
- Verstappen `mu_hat = -0.242969`;
- Table 3 coefficients and `R^2 = 0.3914`;
- second-driver CI `(-0.581, 1.013)`;
- Section 5 flags: Max Verstappen and Fernando Alonso.

The repository's base-R test script encodes these checks.

## Figure audit and provenance

The original dual-page repository also contained a useful descriptive figure
showing each driver's raw 2022 average finishing position, grouped by team. It
has been restored as `figures/03_driver_vs_team.png` and is now explained in
both Quarto pages.

The figure is retained because it makes the constructor effect and within-team
spread visually intuitive. It is explicitly separated from the paper's final
Section 5 calculation: raw 2022 averages are descriptive, whereas the final
threshold is applied to 2023 Qatar odds-implied expected ranks.

All four figures now have a canonical base-R plotting function under
`R/figures/`. The Quarto pages include those exact source files in collapsed
code blocks, and `analysis/generate_figures.R` regenerates the full figure set.
The tests also smoke-test every plotting function by writing a temporary PNG.
