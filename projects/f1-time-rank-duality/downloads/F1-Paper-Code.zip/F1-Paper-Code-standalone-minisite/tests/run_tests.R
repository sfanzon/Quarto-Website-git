# Base-R regression tests against the published paper values.
args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) != 1L) stop("run this file with Rscript")
script_path <- normalizePath(sub("^--file=", "", file_arg))
repo_root <- normalizePath(file.path(dirname(script_path), ".."))
setwd(repo_root)

source("R/00_palette.R")
source("R/00_utils.R")
source("R/01_odds_calibration.R")
source("R/02_rank_duality.R")
source("R/03_regression.R")
source("R/04_driver_effects.R")
source("R/05_visualization.R")

close_enough <- function(actual, expected, tol, label) {
  if (any(abs(actual - expected) > tol)) {
    stop(sprintf("%s failed: max error %.3e exceeds %.3e",
                 label, max(abs(actual - expected)), tol))
  }
}

odds <- read_qatar_odds()
stopifnot(abs(sum(odds$implied_probability) - 1) < 1e-12)
close_enough(odds$implied_probability, odds$paper_probability, 1.5e-9,
             "Table 1 implied probabilities")

calibration <- build_calibration_table(odds)
close_enough(calibration$lambda_paper_scale, calibration$paper_lambda, 2e-9,
             "Table 1 lambda values")
num <- estimate_lambda_numerically(odds$implied_probability, restarts = 10, seed = 1)
close_enough(num$lambda, odds$implied_probability, 1e-6,
             "numerical lambda calibration")

dual <- implied_rank_params(odds$implied_probability)
close_enough(dual$sigma, 3.879374, 1e-6, "Table 2 sigma")
close_enough(dual$mu[odds$driver == "Max Verstappen"], -0.242969, 1e-6,
             "Table 2 Verstappen mu")
close_enough(dual$mu[odds$driver == "Fernando Alonso"], 10.501519, 1e-6,
             "Table 2 Alonso mu")

f1 <- load_f1_2022()
stopifnot(nrow(f1) == 500L, length(unique(f1$event)) == 25L)

driver_averages <- driver_average_table(f1)
stopifnot(nrow(driver_averages) == 20L)
close_enough(
  driver_averages$avg_position[driver_averages$driver == "MaxVerstappen"],
  3.32, 1e-12, "Verstappen descriptive average"
)
close_enough(
  driver_averages$avg_position[driver_averages$driver == "SergioPerez"],
  5.28, 1e-12, "Perez descriptive average"
)

models <- select_models(f1)
expected_terms <- c("(Intercept)", "second_driver", "RedBull", "Mercedes",
                    "Ferrari", "McLaren", "Alpine", "AstonMartin")
stopifnot(setequal(names(coef(models$stepwise)), expected_terms))
expected_coef <- c(13.8420, 0.2160, -9.6500, -8.2700,
                   -7.6900, -3.5500, -3.5500, -1.7900)
actual_coef <- unname(coef(models$stepwise)[expected_terms])
close_enough(actual_coef, expected_coef, 5e-4,
             "Table 3 coefficients")
close_enough(summary(models$stepwise)$r.squared, 0.3914, 5e-5,
             "Table 3 R-squared")

ci <- second_driver_ci(models$stepwise)
close_enough(ci, c(-0.581, 1.013), 5e-4, "Section 5 confidence interval")
gaps <- teammate_gaps(odds, dual$mu, ci["upper"])
flagged <- sort(gaps$leading_driver[gaps$outperforms_car])
stopifnot(identical(flagged, sort(c("Max Verstappen", "Fernando Alonso"))))

# Figure smoke tests: every plotting function must create a non-empty PNG.
figure_dir <- tempfile("f1-figures-")
dir.create(figure_dir)
figure_paths <- file.path(
  figure_dir,
  c("01_lambda_estimates.png", "02_team_effects.png",
    "03_driver_vs_team.png", "04_teammate_gaps.png")
)
plot_lambda_estimates(calibration, figure_paths[1])
plot_team_effects(models$stepwise, figure_paths[2])
plot_driver_vs_team(driver_averages, figure_paths[3])
plot_teammate_gaps(gaps, ci["upper"], figure_paths[4])
stopifnot(all(file.exists(figure_paths)))
stopifnot(all(file.info(figure_paths)$size > 0))
unlink(figure_dir, recursive = TRUE)

cat("All tests passed.\n")
